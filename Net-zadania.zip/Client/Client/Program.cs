﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Client.ClientServerReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            BookServiceClient bookServiceClient = new BookServiceClient();
            Console.WriteLine("Boorowing book");
            Console.WriteLine(bookServiceClient.borrowBook(1, 1).reserved);
            Console.WriteLine(bookServiceClient.borrowBook(1, 2).reserved);
            Console.WriteLine(bookServiceClient.borrowBook(2, 3).reserved);
            Console.WriteLine(bookServiceClient.borrowBook(2, 4).reserved);

            Console.WriteLine("Reserved book try");
            Console.WriteLine(bookServiceClient.borrowBook(1, 3).reserved);

            Console.WriteLine("List borrowed");
            foreach(Book book in bookServiceClient.listBorrowedItems())
            {
                Console.WriteLine("Book id: " + book.bookID + " " + book.bookInfo.author + " " + book.bookInfo.title + " Borrowed: " + book.bookInfo.borrowDate + " Return Date: " + book.returnDate + " USER: " + book.userID);
            }

            BookInfo bookInfo = null;
            Console.WriteLine("Book info");
            try
            {
                bookInfo = bookServiceClient.getBookInfo(22);
            }
            catch (System.ServiceModel.FaultException<BookIdException> e) { }
                
            
            Console.WriteLine("Borrowed books user1");

            foreach(Book book in bookServiceClient.getBorrowedBooks(1))
            {
                Console.WriteLine("Book id: " + book.bookID + " " + book.bookInfo.author + " " + book.bookInfo.title + " Borrowed: " + book.bookInfo.borrowDate + " Return Date: " + book.returnDate );
            }
            Console.ReadLine();
            

        


          
            
        }
    }
}
