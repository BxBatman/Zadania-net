﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class ToysRoom
    {

        public List<Toy> list = new List<Toy>();
        public delegate void LimitToyHandler();
        public event LimitToyHandler limitReached;

        public delegate void AddToyHandler();
        public event AddToyHandler newToyAdded;
        private static System.Threading.Mutex mutex = new System.Threading.Mutex();

        private double limit;
        private double sum = 0;

        public double Limit { get => limit; set => limit = value; }

        
        public void add(Toy toy)
        {
            mutex.WaitOne();
            list.Add(toy);
            newToyAdded();

            try
            {
                if (list.Count > 1)
                {
                    foreach (Toy atoy in list)
                    {
                        sum += atoy.GetActualValue;

                    }
                    if (limit < sum)
                    {
                        limitReached();
                    }
                }
            }
            catch (System.InvalidOperationException ex)
            {

            }
            finally {
                mutex.ReleaseMutex();
            }

        }

        public void deleteLastToy()
        {
            mutex.WaitOne();
            if (list.Count > 1)
            {
                list.RemoveAt(list.Count - 1);
                Console.WriteLine("Last Toy removed");
            }else {
                Console.WriteLine("No toys to remove");
            }
            mutex.ReleaseMutex();
        }

        public void changeSpeedToAll(int speed)
        {
            mutex.WaitOne();
            if (list.Count > 1)
            {
                foreach (Toy toy in list)
                {
                    if (toy is ISpeed)
                    {
                        ISpeed newToy = (ISpeed)toy;
                        newToy.Speed += speed;
                    }
                }
               
            }
            mutex.ReleaseMutex();
        }

        public void changeDepthToAll(int depth)
        {
            mutex.WaitOne();
            if (list.Count > 1)
            {
                foreach (Toy toy in list)
                {
                    if (toy is IDepth)
                    {
                        IDepth newToy = (IDepth)toy;
                        newToy.Depth += depth;
                    }
                }
                
            }
            mutex.ReleaseMutex();
        }


        public void changeHeightToAll(int height)
        {
            mutex.WaitOne();
            if (list.Count > 1)
            {
                foreach (Toy toy in list)
                {
                    if (toy is IHeight)
                    {
                        IHeight newToy = (IHeight)toy;
                        newToy.Height += height;
                    }
                }
               
            }
            mutex.ReleaseMutex();
        }
        public void showAllInfo()
        {
            mutex.WaitOne();
            System.Console.WriteLine("Number of toys " + list.Count);
            System.Console.WriteLine("-----------------");
            int i =1;
            try
            {
                foreach (Toy toy in list)
                {
                    System.Console.WriteLine("Toy number: " + i);
                    System.Console.WriteLine("-----------------");

                    if (toy is ISpeed)
                    {
                        ISpeed newToy = (ISpeed)toy;
                        System.Console.WriteLine("Toy speed: " + newToy.Speed);
                    }

                    if (toy is IHeight)
                    {
                        IHeight newToy = (IHeight)toy;
                        System.Console.WriteLine("Toy height: " + newToy.Height);
                    }

                    if (toy is IDepth)
                    {
                        IDepth newToy = (IDepth)toy;
                        System.Console.WriteLine("Toy depth: " + newToy.Depth);
                    }


                    System.Console.WriteLine("Toy age: " + toy.Age);
                    System.Console.WriteLine("Actual value: " + toy.GetActualValue);
                    System.Console.WriteLine("-----------------");
                    i++;
                }
            }
            catch (InvalidOperationException e) {}
            finally{
                mutex.ReleaseMutex();
            }


           
        }



    }
}
